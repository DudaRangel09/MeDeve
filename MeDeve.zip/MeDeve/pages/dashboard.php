<?php
include "../confgurações/configuracoes.php";
include "../includes/auth.php";
include "../dados/dados.php";
include "../includes/header.php";
include "../includes/menu.php";

$totalPagar = 0;
$totalReceber = 0;
foreach ($contas as $conta) {
    if ($conta["tipo"] === "pagar") {
        $totalPagar += $conta["valor"];
    } else {
        $totalReceber += $conta["valor"];
    }
}
$saldoLiquido = $totalReceber - $totalPagar;
?>

<div class="container mt-4">
    <div class="row mb-4">
        <div class="col-md-4">
            <h2>Bem-vindo, <?= htmlspecialchars($_SESSION["usuario"]) ?>! <small class="text-muted">(<?= htmlspecialchars($_SESSION["perfil"]) ?>)</small></h2>
        </div>
    </div>

    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <div class="card text-bg-warning">
                <div class="card-body">
                    <h5 class="card-title">Contas a Pagar</h5>
                    <h3 class="card-text">R$ <?= number_format($totalPagar, 2, ',', '.') ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-bg-success">
                <div class="card-body">
                    <h5 class="card-title">Contas a Receber</h5>
                    <h3 class="card-text">R$ <?= number_format($totalReceber, 2, ',', '.') ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-bg-info <?= $saldoLiquido >= 0 ? 'text-bg-success' : 'text-bg-danger' ?>">
                <div class="card-body">
                    <h5 class="card-title">Saldo Líquido</h5>
                    <h3 class="card-text <?= $saldoLiquido >= 0 ? '' : 'fw-bold' ?>">R$ <?= number_format($saldoLiquido, 2, ',', '.') ?></h3>
                </div>
            </div>
        </div>
    </div>

    <div class="box">
        <a href="../contas.php" class="btn btn-primary">Gerenciar Contas</a>
    </div>
</div>

<?php include "../includes/footer.php"; ?>

