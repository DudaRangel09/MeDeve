<?php
include "../confgurações/configuracoes.php";
include "../includes/auth.php";
include "../includes/header.php";
include "../includes/menu.php";
include "../dados/dados.php";
?>

<div class="container mt-4">
    <div class="box p-4">
        <h2>Gerenciar Contas</h2>
        <p class="lead">Escolha uma ação:</p>
        <div class="row g-3">
            <div class="col-md-3">
                <a href="contas/listar.php" class="btn btn-outline-primary w-100 h-100 d-flex align-items-center justify-content-center" style="min-height: 120px;">
                    <div>
                        <i class="bi bi-list-ul fs-1 d-block mb-2"></i>
                        <span>Ver Todas</span>
                    </div>
                </a>
            </div>
            <div class="col-md-3">
                <a href="contas/cadastrar.php" class="btn btn-success w-100 h-100 d-flex align-items-center justify-content-center" style="min-height: 120px;">
                    <div>
                        <i class="bi bi-plus-circle fs-1 d-block mb-2"></i>
                        <span>Nova Conta</span>
                    </div>
                </a>
            </div>
        </div>
    </div>
</div>

<?php include "../includes/footer.php"; ?>

