<?php
$perfil = $_SESSION["perfil"];
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">

<a class="navbar-brand" href="../pages/dashboard.php">Financeiro</a>
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" href="dashboard.php">Dashboard</a>
        </li>

<?php if ($perfil === "cliente"): ?>
        <li class="nav-item">
            <a class="nav-link" href="../contas/listar.php">Minhas Contas</a>
        </li>
        <?php elseif ($perfil === "empresa"): ?>
        <li class="nav-item">
            <a class="nav-link" href="../contas/listar.php">Contas Empresa</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="../contas/cadastrar.php">+ Nova Conta</a>
        </li>
        <?php elseif ($perfil === "administrador"): ?>
        <li class="nav-item">
            <a class="nav-link" href="../contas/listar.php">Todas Contas</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="../pages/usuarios.php">Usuários</a> 
        </li>
        <?php endif; ?>

        <li class="nav-item">
            <a class="nav-link text-danger" href="../logout.php">Sair (<?= $_SESSION["usuario"] ?>)</a>
        </li>
    </ul>
    </div>
</nav>
