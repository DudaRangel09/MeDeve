<?php
include "../../confgurações/configuracoes.php";
include "../../includes/auth.php";
include "../../dados/dados.php";

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    header("Location: listar.php?erro=id");
    exit;
}

if (excluirConta($contas, $id)) {
    header("Location: listar.php?msg=excluida");
} else {
    header("Location: listar.php?erro=nao_encontrada");
}
exit;
?>

