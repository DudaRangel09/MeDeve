<?php
include "../../confgurações/configuracoes.php";
include "../../includes/auth.php";
include "../../dados/dados.php";
include "../../includes/header.php";
include "../../includes/menu.php";
?>

<?php 
$msg = $_GET['msg'] ?? '';
$erro = $_GET['erro'] ?? '';
if ($msg == 'nova') echo '<div class="alert alert-success">Conta criada com sucesso!</div>';
if ($msg == 'atualizada') echo '<div class="alert alert-success">Conta atualizada!</div>';
if ($msg == 'excluida') echo '<div class="alert alert-success">Conta excluída!</div>';
if ($erro == 'id') echo '<div class="alert alert-danger">ID inválido.</div>';
if ($erro == 'nao_encontrada') echo '<div class="alert alert-danger">Conta não encontrada.</div>';
?>

<div class="container mt-4">
    <h3>Contas</h3>

    <a href="../contas.php" class="btn btn-secondary mb-3">Voltar</a>
    <a href="cadastrar.php" class="btn btn-primary mb-3">+ Nova Conta</a>

    <table class="table table-bordered shadow-sm">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Descrição</th>
                <th>Valor</th>
                <th>Vencimento</th>
                <th>Status</th>
                <th>Tipo</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($contas as $c): ?>
        <tr>
            <td><?= htmlspecialchars($c["id"]) ?></td>
            <td><?= htmlspecialchars($c["descricao"]) ?></td>
            <td>R$ <?= number_format($c["valor"], 2, ',', '.') ?></td>
            <td><?= date('d/m/Y', strtotime($c["vencimento"])) ?></td>
            <td><span class="badge <?= $c["status"] == 'pendente' ? 'bg-warning' : 'bg-success' ?>"><?= htmlspecialchars($c["status"]) ?></span></td>
            <td><span class="badge <?= $c["tipo"] == 'pagar' ? 'bg-warning text-dark' : 'bg-success' ?>"><?= htmlspecialchars(ucfirst($c["tipo"])) ?></span></td>
            <td>
                <a href="editar.php?id=<?= $c["id"] ?>" class="btn btn-warning btn-sm">Editar</a>
                <a href="excluir.php?id=<?= $c["id"] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Confirmar exclusão?')">Excluir</a>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include "../../includes/footer.php"; ?>

