<?php
include "../../confgurações/configuracoes.php";
include "../../includes/auth.php";
include "../../dados/dados.php";

if ($_POST) {
    adicionarConta($contas, $_POST["descricao"], $_POST["valor"], $_POST["vencimento"], $_POST["status"], strtolower($_POST["tipo"]));
    header("Location: listar.php?msg=nova");
    exit;
}

include "../../includes/header.php";
include "../../includes/menu.php";
?>

<div class="container mt-4">
    <div class="box">
        <h3>+ Nova Conta</h3>

        <form method="POST" action="">
            <div class="mb-3">
                <label class="form-label">Descrição *</label>
                <input name="descricao" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Valor (R$)*</label>
                <input name="valor" class="form-control" type="number" step="0.01" min="0" required>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <label class="form-label">Vencimento</label>
                    <input name="vencimento" type="date" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-control">
                        <option value="pendente">Pendente</option>
                        <option value="pago">Pago</option>
                    </select>
                </div>
            </div>
            <div class="mb-3 mt-3">
                <label class="form-label">Tipo *</label>
                <select name="tipo" class="form-control" required>
                    <option value="pagar">Pagar</option>
                    <option value="receber">Receber</option>
                </select>
            </div>
            <button class="btn btn-success" type="submit">Criar Conta</button>
            <a href="listar.php" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</div>

<?php include "../../includes/footer.php"; ?>

