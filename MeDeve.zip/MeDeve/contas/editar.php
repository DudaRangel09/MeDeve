<?php
include "../../confgurações/configuracoes.php";
include "../../includes/auth.php";
include "../../dados/dados.php";

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    die("ID inválido.");
}

$conta = null;
foreach ($contas as $c) {
    if ($c["id"] == $id) {
        $conta = $c;
        break;
    }
}

if (!$conta) {
    die("Conta não encontrada.");
}

if ($_POST) {
    atualizarConta($contas, $id, $_POST["descricao"], $_POST["valor"], $_POST["vencimento"], $_POST["status"], strtolower($_POST["tipo"]));
    header("Location: listar.php?msg=atualizada");
    exit;
}

include "../../includes/header.php";
include "../../includes/menu.php";
?>

<div class="container mt-4">
    <div class="box">
        <h3>Editar Conta #<?= $id ?></h3>

        <form method="POST" action="">
            <input type="hidden" name="id" value="<?= $id ?>">
            <div class="mb-3">
                <label class="form-label">Descrição *</label>
                <input name="descricao" class="form-control" value="<?= htmlspecialchars($conta['descricao']) ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Valor (R$)*</label>
                <input name="valor" class="form-control" type="number" step="0.01" min="0" value="<?= $conta['valor'] ?>" required>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <label class="form-label">Vencimento</label>
                    <input name="vencimento" type="date" class="form-control" value="<?= $conta['vencimento'] ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-control">
                        <option value="pendente" <?= $conta["status"]=='pendente' ? 'selected' : '' ?>>Pendente</option>
                        <option value="pago" <?= $conta["status"]=='pago' ? 'selected' : '' ?>>Pago</option>
                    </select>
                </div>
            </div>
            <div class="mb-3 mt-3">
                <label class="form-label">Tipo *</label>
                <select name="tipo" class="form-control" required>
                    <option value="pagar" <?= $conta["tipo"]=='pagar' ? 'selected' : '' ?>>Pagar</option>
                    <option value="receber" <?= $conta["tipo"]=='receber' ? 'selected' : '' ?>>Receber</option>
                </select>
            </div>
            <button class="btn btn-warning" type="submit">Salvar Alterações</button>
            <a href="listar.php" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</div>

<?php include "../../includes/footer.php"; ?>

