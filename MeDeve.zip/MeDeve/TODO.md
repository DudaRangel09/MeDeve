# TODO - Completar Sistema Financeiro (Plano Apostila Apostila)

## Progresso Geral: 0/9

### 1. ✅ dados/dados.php (funções adicionar/atualizar/excluirConta)
### 2. ✅ includes/menu.php (cliente/empresa/admin full dinâmico)
### 3. ✅ pages/dashboard.php (cards Pagar/Receber/Saldo dinâmicos)
### 4. ✅ contas/listar.php (cols Vencimento/Status badges + thead dark)
### 5. ✅ contas/cadastrar.php (persist + vencimento/status/date)
### 6. ✅ contas/editar.php (persist + full campos/selects)
### 7. ✅ contas/excluir.php (persist + erros)
### 8. ✅ Testes: 3 perfis/menus + CRUD (add/edit/del persiste + msgs + totais update)
### 9. ✅ contas.php polish + sistema 100% apostila

**Notas**:
- Senha: 123456
- Perfis: cliente/empresa/administrador
- Persistência: arrays em dados/dados.php (reload page testa)

