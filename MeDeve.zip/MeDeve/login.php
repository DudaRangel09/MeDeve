<?php
include 'confgurações/configuracoes.php';
include 'dados/dados.php';
session_start();

$erro = "";
if ($_POST) {
    foreach ($usuarios as $u) {
        if ($_POST["usuario"] === $u["usuario"] && $_POST["senha"] === $u["senha"]) {
            $_SESSION["usuario"] = $u["usuario"];
            $_SESSION["perfil"] = $u["perfil"];
            header("Location: pages/dashboard.php");
            exit;
        }
    }

    $erro = "Usuário ou senha inválidos.";
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/custom.css">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="col-md-4 offset-md-4">
            <h3 class="text-center">Acesso ao sistema</h3>

            <form method="post">
                <input class="form-control mb-3" type="text" name="usuario" placeholder="Usuário" required>
                <input class="form-control mb-3" type="password" name="senha" placeholder="Senha" required>

                <?php if ($erro): ?>
                    <p class="text-danger text-center"><?= $erro ?></p>
                    <?php endif; ?>
                <button class="btn btn-primary w-100">Entrar</button>
            </form>
        </div>
    
</body>
</html>