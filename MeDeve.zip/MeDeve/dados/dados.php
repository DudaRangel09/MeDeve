<?php
$usuarios = [
    ["usuario" => "cliente",
    "senha" => "123456",
    "perfil" => "cliente"],

    ["usuario" => "admin",
    "senha" => "123456",
    "perfil" => "administrador"],

    ["usuario" => "empresa",
    "senha" => "123456",
    "perfil" => "empresa"],

    ];

$contas = [
    ["id" => 1,
    "descricao" => "Conta de luz",
    "valor" => 150,
    "vencimento" => "2026-04-25",
    "status" => "pendente",
    "tipo" => "pagar"
    ],
    ["id" => 2,
    "descricao" => "Aluguel",
    "valor" => 1200,
    "vencimento" => "2026-05-01",
    "status" => "pendente",
    "tipo" => "receber"
    ]
];

function adicionarConta(&$contas, $descricao, $valor, $vencimento, $status, $tipo) {
    $nextId = empty($contas) ? 1 : max(array_column($contas, "id")) + 1;
    $contas[] = [
        "id" => $nextId,
        "descricao" => $descricao,
        "valor" => (float)$valor,
        "vencimento" => $vencimento,
        "status" => $status,
        "tipo" => $tipo
    ];
}

function atualizarConta(&$contas, $id, $descricao, $valor, $vencimento, $status, $tipo) {
    foreach ($contas as &$conta) {
        if ($conta["id"] == $id) {
            $conta["descricao"] = $descricao;
            $conta["valor"] = (float)$valor;
            $conta["vencimento"] = $vencimento;
            $conta["status"] = $status;
            $conta["tipo"] = $tipo;
            return true;
        }
    }
    return false;
}

function excluirConta(&$contas, $id) {
    foreach ($contas as $key => $conta) {
        if ($conta["id"] == $id) {
            unset($contas[$key]);
            $contas = array_values($contas);  
            return true;
        }
    }
    return false;
}
?>